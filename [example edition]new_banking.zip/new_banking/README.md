Based on onlyserenity script (https://github.com/onlyserenity/new_banking)
New UI and some improvments

---

FXServer NEW_BANKING

[REQUIREMENTS]

Dependencies For Full Functionality

es_extended => https://github.com/ESX-Org/es_extended

Install To resources/[esx]/new_banking << MUST BE INSTALLED HERE

Add this in your server.cfg :
start new_banking

Credits: Script Created By: @onlyserenity(amjedcha) edited and improved by NewWay

Discord: https://discord.gg/dSYb4j2

---

![](https://i.imgur.com/bjfLLr9.png)
![](https://i.imgur.com/JnlPAHN.png)
![](https://i.imgur.com/OU5B0yo.png)
![](https://i.imgur.com/t9axH2n.png)
![](https://i.imgur.com/MH7MdKA.png)